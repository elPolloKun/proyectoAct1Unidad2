package com.example.proyectoact1uni2

data class TacoDrinks (val name: String, val latitud:Double, val longitude: Double)