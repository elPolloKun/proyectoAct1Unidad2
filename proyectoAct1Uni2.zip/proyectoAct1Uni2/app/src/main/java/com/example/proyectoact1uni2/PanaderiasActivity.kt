package com.example.proyectoact1uni2


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class Panaderia(val nombre: String, val direccion: String)

class PanaderiasActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PanaderiaAdapter
    private val panaderias: MutableList<Panaderia> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panaderias)

        // Agrega tus objetos Panaderia a la lista
        panaderias.add(Panaderia("EL RICO PAN DE DARIO", "Latitud: 19.93198609, Longitud: -96.8500795"))
        panaderias.add(Panaderia("PANADERIA ACOSTA", "Latitud: 19.93062887, Longitud: -96.85487505"))
        panaderias.add(Panaderia("NELLY S PASTELERIA", "Latitud: 19.92801022, Longitud: -96.85938506"))
        panaderias.add(Panaderia("PANADERIA ALEX Y ADRIAN", "Latitud: 19.92723981, Longitud: -96.8563708"))
        panaderias.add(Panaderia("PANADERIA CASTAÑEDA", "Latitud: 19.92909211, Longitud: -96.84971515"))
        panaderias.add(Panaderia("PANADERIA DE ORDUÑA", "Latitud: 19.92801022, Longitud: -96.85938506"))
        panaderias.add(Panaderia("PANADERIA DOS HERMANOS", "Latitud: 19.94411533, Longitud: -96.85421902"))
        panaderias.add(Panaderia("PANADERIA EJ", "Latitud: 20.02281153, Longitud: -96.87226284"))
        panaderias.add(Panaderia("PANADERIA EL MANA", "Latitud: 19.92617414, Longitud: -96.8546617"))
        panaderias.add(Panaderia("PANADERIA EL ZOTUCO", "Latitud: 19.92849723, Longitud: -96.85067704"))
        panaderias.add(Panaderia("PANADERIA LA CASA DEL VOLOVAN", "Latitud: 19.93074402, Longitud: -96.85334411"))
        panaderias.add(Panaderia("PANADERIA MARIANA", "Latitud: 19.9282138, Longitud: -96.85655187"))
        panaderias.add(Panaderia("PANADERIA NEY", "Latitud: 19.92648395, Longitud: -96.85541671"))
        panaderias.add(Panaderia("PANADERIA PERALTA", "Latitud: 19.92617952, Longitud: -96.85310211"))
        panaderias.add(Panaderia("PANADERIA SAN MARTIN", "Latitud: 19.92648395, Longitud: -96.85541671"))
        panaderias.add(Panaderia("PANADERIA XALAPA", "Latitud: 19.92501335, Longitud: -96.8546908"))
        panaderias.add(Panaderia("PANADERIA ZAYAS", "Latitud: 19.93716787, Longitud: -96.8524113"))
        panaderias.add(Panaderia("PASTELERIA FRAMBUESA", "Latitud: 19.92755031, Longitud: -96.85541671"))

        recyclerView = findViewById(R.id.recyclerView)
        adapter = PanaderiaAdapter(panaderias)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}

