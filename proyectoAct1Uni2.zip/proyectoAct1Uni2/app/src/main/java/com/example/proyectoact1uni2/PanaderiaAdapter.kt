package com.example.proyectoact1uni2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PanaderiaAdapter(private val panaderias: List<Panaderia>) : RecyclerView.Adapter<PanaderiaAdapter.PanaderiaViewHolder>() {

    inner class PanaderiaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nombreTextView: TextView = itemView.findViewById(R.id.nombreTextView)
        private val direccionTextView: TextView = itemView.findViewById(R.id.direccionTextView)

        fun bind(panaderia: Panaderia) {
            nombreTextView.text = panaderia.nombre
            direccionTextView.text = panaderia.direccion
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PanaderiaViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_panaderia, parent, false)
        return PanaderiaViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PanaderiaViewHolder, position: Int) {
        val panaderia = panaderias[position]
        holder.bind(panaderia)
    }

    override fun getItemCount(): Int {
        return panaderias.size
    }
}
