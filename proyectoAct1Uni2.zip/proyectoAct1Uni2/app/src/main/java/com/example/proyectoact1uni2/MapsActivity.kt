package com.example.proyectoact1uni2

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import androidx.appcompat.app.AlertDialog
import com.example.proyectoact1uni2.databinding.ActivityMapsBinding
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.*
import com.google.maps.DirectionsApi
import com.google.maps.GeoApiContext
import com.google.maps.model.TravelMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


private const val LOCATION_PERMISSION_REQUEST_CODE = 2000
private const val DEFAULT_MAP_SCALE = 13.0f

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val taquerias_Drinks = mutableListOf<TacoDrinks>()
    private lateinit var tacoIcon: BitmapDescriptor
    private val userLocation = Location("")
    var poly: Polyline? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        taquerias_Drinks.add(TacoDrinks("EL RICO PAN DE DARIO", 19.93198609, -96.8500795))
        taquerias_Drinks.add(TacoDrinks("PANADERIA ACOSTA", 19.93062887, -96.85270143))
        taquerias_Drinks.add(
            TacoDrinks(
                "NELLY S PASTELERIA",
                19.92801022,
                -96.85487505
            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA ALEX Y ADRIAN",
                19.92723981,
                -96.8563708
            )
        )
        taquerias_Drinks.add(TacoDrinks("PANADERIA BIMBO", 19.92851615619422, -96.8533578515053))
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA CASTAÑEDA",
                19.92909211,
                -96.84971515
            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA DE ORDUÑA",
                19.92940357,
                -96.85363233

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA DOS HERMANOS",
                19.94411533,
                -96.85421902

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA EJ",
                20.02281153,
                -96.87226284

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA EL MANA",
                19.92617414,
                -96.8546617

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA EL ZOTUCO",
                19.92849723,
                -96.85067704

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA LA CASA DEL VOLOVAN",
                19.93074402,
                -96.85334411

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA MARIANA",
                19.9282138,
                -96.85655187

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA NEY",
                19.92648395,
                -96.85541671

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA PERALTA",
                19.92617952,
                -96.85310211

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA SAN MARTIN",
                19.92959529,
                -96.84255151

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA XALAPA",
                19.92501335,
                -96.8546908

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PANADERIA ZAYAS",
                19.93716787,
                -96.8524113

            )
        )
        taquerias_Drinks.add(
            TacoDrinks(
                "PASTELERIA FRAMBUESA",
                19.92755031,
                -96.85310409

            )
        )


        tacoIcon = getTacoIcon()

        checkLocationPermission()
    }

    fun mostrarPanaderias(view: View) {
        val intent = Intent(this, PanaderiasActivity::class.java)
        startActivity(intent)
    }



    private fun checkLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                getUserLocation()
            } else {
                requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            }
        } else {
            getUserLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getUserLocation() {
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                userLocation.latitude = location.latitude
                userLocation.longitude = location.longitude
                setupMap()
            }
        }
    }


    private fun setupMap() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                getUserLocation()
            } else if (shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                showLocationPermissionRationaleDialog()
            } else {
                finish()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun showLocationPermissionRationaleDialog() {
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.need_location_permission_dialog_title)
            .setMessage(R.string.need_location_permission_dialog_message)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                    LOCATION_PERMISSION_REQUEST_CODE)
            }.setNegativeButton(R.string.no) { _, _ ->
                finish()
            }
        dialog.show()
    }

    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val userLatLng = LatLng(userLocation.latitude, userLocation.longitude)
        val userMarker = MarkerOptions().position(userLatLng)
        mMap.addMarker(userMarker)

        for (taqueria in taquerias_Drinks) {
            val tacoPosition = LatLng(taqueria.latitud, taqueria.longitude)
            val tacoLocation = Location("")

            tacoLocation.latitude = taqueria.latitud
            tacoLocation.longitude = taqueria.longitude

            val distanceToTaco = tacoLocation.distanceTo(userLocation)

            val tacoMarkerOptions = MarkerOptions()
                .icon(tacoIcon)
                .position(tacoPosition)
                .title(taqueria.name)
                .snippet(getString(R.string.distance_to_format, distanceToTaco))
            mMap.addMarker(tacoMarkerOptions)
        }

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, DEFAULT_MAP_SCALE))

        mMap.setOnMarkerClickListener { marker ->

            for (taquerias_Drinks in taquerias_Drinks) {
                val taquerias_DrinksLatLng = LatLng(taquerias_Drinks.latitud, taquerias_Drinks.longitude)
                if (marker.position == taquerias_DrinksLatLng) {
                    val selectedtaquerias_Drinks = taquerias_Drinks
                    val destination = LatLng(selectedtaquerias_Drinks.latitud, selectedtaquerias_Drinks.longitude)
                    getDirectionsToLocation(destination)
                    break
                }
            }
            false
        }
    }
    private fun getTacoIcon(): BitmapDescriptor {
        val drawable = ContextCompat.getDrawable(this, R.drawable.pan)
        drawable?.setBounds(0, 0, drawable.intrinsicWidth, drawable.intrinsicHeight)
        val bitmap = Bitmap.createBitmap(drawable?.intrinsicWidth ?: 0,
            drawable?.intrinsicHeight ?: 0, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable?.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }
    private fun getDirectionsToLocation(destination: LatLng) {
        val origin = "${userLocation.latitude},${userLocation.longitude}"
        val destinationString = "${destination.latitude},${destination.longitude}"

        GlobalScope.launch(Dispatchers.Main) {
            try {
                val context = GeoApiContext.Builder()
                    .apiKey("AIzaSyC_r2vpSXOEen0IKp4EDfVnR7LyKVd0ii0")
                    .build()
                val directionsResult = DirectionsApi.newRequest(context)
                    .mode(TravelMode.DRIVING)
                    .origin(origin)
                    .destination(destinationString)
                    .await()
                if (directionsResult.routes.isNotEmpty()) {
                    val route = directionsResult.routes[0]
                    val points = route.overviewPolyline.decodePath()

                    val polylineOptions = PolylineOptions()
                        .addAll(points.map { LatLng(it.lat, it.lng) })
                        .color(Color.YELLOW)
                        .width(5f)
                    if (poly != null) {
                        poly!!.remove()
                    }
                    poly = mMap.addPolyline(polylineOptions)
                } else {
                    Toast.makeText(this@MapsActivity, "No se encontró una ruta", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MapsActivity, "Error al obtener las direcciones: ${e.message}", Toast.LENGTH_SHORT).show()
                Log.e(TAG,"Error al obtener las direcciones: ${e.message}")
            }
        }
    }
}